def f():
    print "f()"
def f(x):
    print "f(x)"
f(3)
