class Foo:
    x = 0

    def __init__(self):
        self.x = 42
