y = x
x = x
class T:
    def p(self):
        a = x
    b = x

def f():
    x = y
    def g():
        a = y
    y = x
    x = y
    x = x
