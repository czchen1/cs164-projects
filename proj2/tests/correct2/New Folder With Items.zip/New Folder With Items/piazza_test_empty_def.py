def f(): pass
