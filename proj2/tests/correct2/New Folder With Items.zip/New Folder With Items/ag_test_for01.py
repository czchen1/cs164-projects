for x in "abc": print x

for y in [1, 2, 3]: print y

for z in xrange(1, 4): print z
