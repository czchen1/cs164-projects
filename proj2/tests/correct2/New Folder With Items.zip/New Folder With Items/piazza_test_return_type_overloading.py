def f():
    return 1
def f():
    return "1"
x::int = f()
