def f():
    return 5
g = f
