def id(x):
    return x
print id(3)
