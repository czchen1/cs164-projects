if True:
    x = 1
else:
    x = 3
print x
