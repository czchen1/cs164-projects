def ident(x):
 return x

a = ident(123)
b = ident("abc")