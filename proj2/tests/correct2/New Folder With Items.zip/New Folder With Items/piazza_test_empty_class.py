class Foo: pass
