if True:
    a = None
    a = 1
