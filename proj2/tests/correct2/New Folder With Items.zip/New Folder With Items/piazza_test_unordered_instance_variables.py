class C:
    x = y
    y = 1
