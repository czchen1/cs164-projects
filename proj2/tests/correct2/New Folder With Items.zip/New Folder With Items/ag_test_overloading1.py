def f(x):
    print x

def f(x, y):
    print x, y

f(3)
f(3,4)
