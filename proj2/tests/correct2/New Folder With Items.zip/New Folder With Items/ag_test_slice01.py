L = [1, 2, 3, 4, 5]
S = ["the", "cat", "in", "the", "hat", "returns"]

Z0 = L[1:3]
Z::list of int = L[1:3]
R::list of str = S[1:4]

L[0:2] = [-1, 0, 1]

print L, S, Z0, Z, R
