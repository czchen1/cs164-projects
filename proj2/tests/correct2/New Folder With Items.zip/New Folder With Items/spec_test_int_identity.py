def sub(x,y):
    return x-y
def intid(z::int):
    return z
print sub(intid(3), 2)
