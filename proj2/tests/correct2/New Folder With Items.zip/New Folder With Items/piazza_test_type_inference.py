def f()::$T:
    return 3

def f(x::$T):
    return 3 + x
