def f()::int:  pass
def f()::bool: pass
def g()::str:  pass
def g()::bool: pass
x = f() and g()
